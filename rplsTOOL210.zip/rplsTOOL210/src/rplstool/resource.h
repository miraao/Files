//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rplstool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RPLSTOOL_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDC_RELOAD                      1000
#define IDC_EDIT1                       1001
#define IDC_FNAME                       1001
#define IDC_FSELECT                     1002
#define IDC_RECYEAR                     1003
#define IDC_RECMONTH                    1004
#define IDC_RECDAY                      1005
#define IDC_RECHOUR                     1006
#define IDC_RECMIN                      1007
#define IDC_RECSEC                      1008
#define IDC_DURHOUR                     1009
#define IDC_DURMIN                      1010
#define IDC_DURSEC                      1011
#define IDC_TIMEZONE                    1012
#define IDC_MAKERID                     1013
#define IDC_MODELCODE                   1014
#define IDC_CHANNELNAME                 1015
#define IDC_CHANNELNUM                  1016
#define IDC_PNAME                       1017
#define IDC_PDETAL                      1018
#define IDC_PDETAIL                     1018
#define IDC_PEXTEND                     1019
#define IDC_GENREL                      1020
#define IDC_COMBO2                      1021
#define IDC_GENREM                      1021
#define IDC_TOOLNAME                    1022
#define IDC_TOOLNAME1                   1022
#define IDC_GENREL2                     1022
#define IDC_TOOLNAME2                   1023
#define IDC_GENREM2                     1023
#define IDC_TEXTFINFO                   1024
#define IDC_TEXTPGENRE                  1025
#define IDC_TEXTPEXTEND                 1026
#define IDC_TEXTRECSRC                  1027
#define IDC_RECSRC                      1028
#define IDC_SPLIT1                      1029
#define IDC_GENREL3                     1029
#define IDC_GENREM3                     1030
#define ID_32771                        32771
#define ID_32772                        32772
#define ID__32773                       32773
#define ID__32774                       32774
#define ID__CSV32775                    32775
#define ID__MENU_TEXT                   32776
#define ID__MENU_ITEMNAME               32777
#define ID__MENU_CSV                    32778
#define ID__32779                       32779
#define ID__32780                       32780
#define ID__32781                       32781
#define ID__32782                       32782
#define ID__32783                       32783
#define ID__32784                       32784
#define ID__32785                       32785
#define ID__32786                       32786
#define ID__32787                       32787
#define ID__32788                       32788
#define ID__32789                       32789
#define ID__32790                       32790
#define ID__32791                       32791
#define ID__MENU_FNAME                  32792
#define ID__MENU_RECDATE                32793
#define ID__MENU_RECTIME                32794
#define ID__MENU_DURTIME                32795
#define ID__MENU_TIMEZONE               32796
#define ID__MENU_MAKERID                32797
#define ID__MENU_MODELCODE              32798
#define ID__MENU_CHNAME                 32799
#define ID__MENU_CHNUM                  32800
#define ID__MENU_PNAME                  32801
#define ID__MENU_PDETAIL                32802
#define ID__MENU_PEXTEND                32803
#define ID__MENU_PGENRE                 32804
#define ID__HO                          32805
#define ID__MENU_RECSRC                 32806

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32807
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
